
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;
import org.junit.Test;

import com.ctg.ag.sdk.core.constant.Scheme;
import com.ctg.ag.sdk.core.model.ApiCallBack;

import com.ctg.ag.sdk.biz.AepDeviceCommandCancelClient;
import com.ctg.ag.sdk.biz.aep_device_command_cancel.CancelAllCommandRequest;
import com.ctg.ag.sdk.biz.aep_device_command_cancel.CancelAllCommandResponse;


public class AepDeviceCommandCancelDemo {

	// 没有签名同步调用接口示例
	@Test
	public void testApi() throws Exception {

		AepDeviceCommandCancelClient client = AepDeviceCommandCancelClient.newClient().build();

		{
			CancelAllCommandRequest request = new CancelAllCommandRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.CancelAllCommand(request));
		}
		
		client.shutdown();

	}

	// 没有签名异步调用接口示例
	@Test
	public void testApiAsync() throws Exception {

		AepDeviceCommandCancelClient client = AepDeviceCommandCancelClient.newClient().build();

		{
			
			List<Future<CancelAllCommandResponse>> res = new ArrayList<Future<CancelAllCommandResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				CancelAllCommandRequest request = new CancelAllCommandRequest();
				// request.setParam..  	// set your request params here

				res.add(client.CancelAllCommand(request, new ApiCallBack<CancelAllCommandRequest, CancelAllCommandResponse>() {
					@Override
					public void onFailure(CancelAllCommandRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(CancelAllCommandRequest request, CancelAllCommandResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<CancelAllCommandResponse> future : res)
				System.out.println(future.get());

		}
		
		client.shutdown();
	}

	// 没有签名https同步调用接口示例
	@Test
	public void testApiWithSsl() throws Exception {

		AepDeviceCommandCancelClient client = AepDeviceCommandCancelClient.newClient().scheme(Scheme.HTTPS).build();

		{
			CancelAllCommandRequest request = new CancelAllCommandRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.CancelAllCommand(request));
		}
		
		client.shutdown();
	}

	// 签名同步调用接口示例
	@Test
	public void testApiWithSignature() throws Exception {

		AepDeviceCommandCancelClient client = AepDeviceCommandCancelClient.newClient().appKey("Your app key here").appSecret("Your app secret here").build();

		{
			CancelAllCommandRequest request = new CancelAllCommandRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.CancelAllCommand(request));
		}
		
		client.shutdown();
	}

}
