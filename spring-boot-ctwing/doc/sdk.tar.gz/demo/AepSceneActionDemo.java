
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;
import org.junit.Test;

import com.ctg.ag.sdk.core.constant.Scheme;
import com.ctg.ag.sdk.core.model.ApiCallBack;

import com.ctg.ag.sdk.biz.AepSceneActionClient;
import com.ctg.ag.sdk.biz.aep_scene_action.QueryActionListRequest;
import com.ctg.ag.sdk.biz.aep_scene_action.QueryActionListResponse;
import com.ctg.ag.sdk.biz.aep_scene_action.QuerySceneListRequest;
import com.ctg.ag.sdk.biz.aep_scene_action.QuerySceneListResponse;
import com.ctg.ag.sdk.biz.aep_scene_action.ActionExecuteRequest;
import com.ctg.ag.sdk.biz.aep_scene_action.ActionExecuteResponse;
import com.ctg.ag.sdk.biz.aep_scene_action.SceneExecuteRequest;
import com.ctg.ag.sdk.biz.aep_scene_action.SceneExecuteResponse;


public class AepSceneActionDemo {

	// 没有签名同步调用接口示例
	@Test
	public void testApi() throws Exception {

		AepSceneActionClient client = AepSceneActionClient.newClient().build();

		{
			QueryActionListRequest request = new QueryActionListRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QueryActionList(request));
		}
		
		{
			QuerySceneListRequest request = new QuerySceneListRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QuerySceneList(request));
		}
		
		{
			ActionExecuteRequest request = new ActionExecuteRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.ActionExecute(request));
		}
		
		{
			SceneExecuteRequest request = new SceneExecuteRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.SceneExecute(request));
		}
		
		client.shutdown();

	}

	// 没有签名异步调用接口示例
	@Test
	public void testApiAsync() throws Exception {

		AepSceneActionClient client = AepSceneActionClient.newClient().build();

		{
			
			List<Future<QueryActionListResponse>> res = new ArrayList<Future<QueryActionListResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				QueryActionListRequest request = new QueryActionListRequest();
				// request.setParam..  	// set your request params here

				res.add(client.QueryActionList(request, new ApiCallBack<QueryActionListRequest, QueryActionListResponse>() {
					@Override
					public void onFailure(QueryActionListRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(QueryActionListRequest request, QueryActionListResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<QueryActionListResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<QuerySceneListResponse>> res = new ArrayList<Future<QuerySceneListResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				QuerySceneListRequest request = new QuerySceneListRequest();
				// request.setParam..  	// set your request params here

				res.add(client.QuerySceneList(request, new ApiCallBack<QuerySceneListRequest, QuerySceneListResponse>() {
					@Override
					public void onFailure(QuerySceneListRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(QuerySceneListRequest request, QuerySceneListResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<QuerySceneListResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<ActionExecuteResponse>> res = new ArrayList<Future<ActionExecuteResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				ActionExecuteRequest request = new ActionExecuteRequest();
				// request.setParam..  	// set your request params here

				res.add(client.ActionExecute(request, new ApiCallBack<ActionExecuteRequest, ActionExecuteResponse>() {
					@Override
					public void onFailure(ActionExecuteRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(ActionExecuteRequest request, ActionExecuteResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<ActionExecuteResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<SceneExecuteResponse>> res = new ArrayList<Future<SceneExecuteResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				SceneExecuteRequest request = new SceneExecuteRequest();
				// request.setParam..  	// set your request params here

				res.add(client.SceneExecute(request, new ApiCallBack<SceneExecuteRequest, SceneExecuteResponse>() {
					@Override
					public void onFailure(SceneExecuteRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(SceneExecuteRequest request, SceneExecuteResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<SceneExecuteResponse> future : res)
				System.out.println(future.get());

		}
		
		client.shutdown();
	}

	// 没有签名https同步调用接口示例
	@Test
	public void testApiWithSsl() throws Exception {

		AepSceneActionClient client = AepSceneActionClient.newClient().scheme(Scheme.HTTPS).build();

		{
			QueryActionListRequest request = new QueryActionListRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QueryActionList(request));
		}
		
		{
			QuerySceneListRequest request = new QuerySceneListRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QuerySceneList(request));
		}
		
		{
			ActionExecuteRequest request = new ActionExecuteRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.ActionExecute(request));
		}
		
		{
			SceneExecuteRequest request = new SceneExecuteRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.SceneExecute(request));
		}
		
		client.shutdown();
	}

	// 签名同步调用接口示例
	@Test
	public void testApiWithSignature() throws Exception {

		AepSceneActionClient client = AepSceneActionClient.newClient().appKey("Your app key here").appSecret("Your app secret here").build();

		{
			QueryActionListRequest request = new QueryActionListRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QueryActionList(request));
		}
		
		{
			QuerySceneListRequest request = new QuerySceneListRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QuerySceneList(request));
		}
		
		{
			ActionExecuteRequest request = new ActionExecuteRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.ActionExecute(request));
		}
		
		{
			SceneExecuteRequest request = new SceneExecuteRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.SceneExecute(request));
		}
		
		client.shutdown();
	}

}
