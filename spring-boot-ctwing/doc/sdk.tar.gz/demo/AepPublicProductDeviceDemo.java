
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;
import org.junit.Test;

import com.ctg.ag.sdk.core.constant.Scheme;
import com.ctg.ag.sdk.core.model.ApiCallBack;

import com.ctg.ag.sdk.biz.AepPublicProductDeviceClient;
import com.ctg.ag.sdk.biz.aep_public_product_device.QueryDeviceTokenRequest;
import com.ctg.ag.sdk.biz.aep_public_product_device.QueryDeviceTokenResponse;


public class AepPublicProductDeviceDemo {

	// 没有签名同步调用接口示例
	@Test
	public void testApi() throws Exception {

		AepPublicProductDeviceClient client = AepPublicProductDeviceClient.newClient().build();

		{
			QueryDeviceTokenRequest request = new QueryDeviceTokenRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QueryDeviceToken(request));
		}
		
		client.shutdown();

	}

	// 没有签名异步调用接口示例
	@Test
	public void testApiAsync() throws Exception {

		AepPublicProductDeviceClient client = AepPublicProductDeviceClient.newClient().build();

		{
			
			List<Future<QueryDeviceTokenResponse>> res = new ArrayList<Future<QueryDeviceTokenResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				QueryDeviceTokenRequest request = new QueryDeviceTokenRequest();
				// request.setParam..  	// set your request params here

				res.add(client.QueryDeviceToken(request, new ApiCallBack<QueryDeviceTokenRequest, QueryDeviceTokenResponse>() {
					@Override
					public void onFailure(QueryDeviceTokenRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(QueryDeviceTokenRequest request, QueryDeviceTokenResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<QueryDeviceTokenResponse> future : res)
				System.out.println(future.get());

		}
		
		client.shutdown();
	}

	// 没有签名https同步调用接口示例
	@Test
	public void testApiWithSsl() throws Exception {

		AepPublicProductDeviceClient client = AepPublicProductDeviceClient.newClient().scheme(Scheme.HTTPS).build();

		{
			QueryDeviceTokenRequest request = new QueryDeviceTokenRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QueryDeviceToken(request));
		}
		
		client.shutdown();
	}

	// 签名同步调用接口示例
	@Test
	public void testApiWithSignature() throws Exception {

		AepPublicProductDeviceClient client = AepPublicProductDeviceClient.newClient().appKey("Your app key here").appSecret("Your app secret here").build();

		{
			QueryDeviceTokenRequest request = new QueryDeviceTokenRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.QueryDeviceToken(request));
		}
		
		client.shutdown();
	}

}
