
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;
import org.junit.Test;

import com.ctg.ag.sdk.core.constant.Scheme;
import com.ctg.ag.sdk.core.model.ApiCallBack;

import com.ctg.ag.sdk.biz.DeviceArchivesClient;
import com.ctg.ag.sdk.biz.device_archives.DeleteArchivesInfoRequest;
import com.ctg.ag.sdk.biz.device_archives.DeleteArchivesInfoResponse;
import com.ctg.ag.sdk.biz.device_archives.GetArchivesAttributeRequest;
import com.ctg.ag.sdk.biz.device_archives.GetArchivesAttributeResponse;
import com.ctg.ag.sdk.biz.device_archives.UpdateArchivesInfoRequest;
import com.ctg.ag.sdk.biz.device_archives.UpdateArchivesInfoResponse;
import com.ctg.ag.sdk.biz.device_archives.AddArchivesInfoRequest;
import com.ctg.ag.sdk.biz.device_archives.AddArchivesInfoResponse;
import com.ctg.ag.sdk.biz.device_archives.GetArchivesInfoRequest;
import com.ctg.ag.sdk.biz.device_archives.GetArchivesInfoResponse;
import com.ctg.ag.sdk.biz.device_archives.GetDeviceTypeRequest;
import com.ctg.ag.sdk.biz.device_archives.GetDeviceTypeResponse;


public class DeviceArchivesDemo {

	// 没有签名同步调用接口示例
	@Test
	public void testApi() throws Exception {

		DeviceArchivesClient client = DeviceArchivesClient.newClient().build();

		{
			DeleteArchivesInfoRequest request = new DeleteArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.DeleteArchivesInfo(request));
		}
		
		{
			GetArchivesAttributeRequest request = new GetArchivesAttributeRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetArchivesAttribute(request));
		}
		
		{
			UpdateArchivesInfoRequest request = new UpdateArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.UpdateArchivesInfo(request));
		}
		
		{
			AddArchivesInfoRequest request = new AddArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.AddArchivesInfo(request));
		}
		
		{
			GetArchivesInfoRequest request = new GetArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetArchivesInfo(request));
		}
		
		{
			GetDeviceTypeRequest request = new GetDeviceTypeRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetDeviceType(request));
		}
		
		client.shutdown();

	}

	// 没有签名异步调用接口示例
	@Test
	public void testApiAsync() throws Exception {

		DeviceArchivesClient client = DeviceArchivesClient.newClient().build();

		{
			
			List<Future<DeleteArchivesInfoResponse>> res = new ArrayList<Future<DeleteArchivesInfoResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				DeleteArchivesInfoRequest request = new DeleteArchivesInfoRequest();
				// request.setParam..  	// set your request params here

				res.add(client.DeleteArchivesInfo(request, new ApiCallBack<DeleteArchivesInfoRequest, DeleteArchivesInfoResponse>() {
					@Override
					public void onFailure(DeleteArchivesInfoRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(DeleteArchivesInfoRequest request, DeleteArchivesInfoResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<DeleteArchivesInfoResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<GetArchivesAttributeResponse>> res = new ArrayList<Future<GetArchivesAttributeResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				GetArchivesAttributeRequest request = new GetArchivesAttributeRequest();
				// request.setParam..  	// set your request params here

				res.add(client.GetArchivesAttribute(request, new ApiCallBack<GetArchivesAttributeRequest, GetArchivesAttributeResponse>() {
					@Override
					public void onFailure(GetArchivesAttributeRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(GetArchivesAttributeRequest request, GetArchivesAttributeResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<GetArchivesAttributeResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<UpdateArchivesInfoResponse>> res = new ArrayList<Future<UpdateArchivesInfoResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				UpdateArchivesInfoRequest request = new UpdateArchivesInfoRequest();
				// request.setParam..  	// set your request params here

				res.add(client.UpdateArchivesInfo(request, new ApiCallBack<UpdateArchivesInfoRequest, UpdateArchivesInfoResponse>() {
					@Override
					public void onFailure(UpdateArchivesInfoRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(UpdateArchivesInfoRequest request, UpdateArchivesInfoResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<UpdateArchivesInfoResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<AddArchivesInfoResponse>> res = new ArrayList<Future<AddArchivesInfoResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				AddArchivesInfoRequest request = new AddArchivesInfoRequest();
				// request.setParam..  	// set your request params here

				res.add(client.AddArchivesInfo(request, new ApiCallBack<AddArchivesInfoRequest, AddArchivesInfoResponse>() {
					@Override
					public void onFailure(AddArchivesInfoRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(AddArchivesInfoRequest request, AddArchivesInfoResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<AddArchivesInfoResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<GetArchivesInfoResponse>> res = new ArrayList<Future<GetArchivesInfoResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				GetArchivesInfoRequest request = new GetArchivesInfoRequest();
				// request.setParam..  	// set your request params here

				res.add(client.GetArchivesInfo(request, new ApiCallBack<GetArchivesInfoRequest, GetArchivesInfoResponse>() {
					@Override
					public void onFailure(GetArchivesInfoRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(GetArchivesInfoRequest request, GetArchivesInfoResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<GetArchivesInfoResponse> future : res)
				System.out.println(future.get());

		}
		
		{
			
			List<Future<GetDeviceTypeResponse>> res = new ArrayList<Future<GetDeviceTypeResponse>>();
			
			// multi request
			for (int i = 0; i < 5; i++) {
			
				GetDeviceTypeRequest request = new GetDeviceTypeRequest();
				// request.setParam..  	// set your request params here

				res.add(client.GetDeviceType(request, new ApiCallBack<GetDeviceTypeRequest, GetDeviceTypeResponse>() {
					@Override
					public void onFailure(GetDeviceTypeRequest request, Exception e) {
						e.printStackTrace();
					}
		
					@Override
					public void onResponse(GetDeviceTypeRequest request, GetDeviceTypeResponse response) {
						System.out.println("Receive data and handle it");
					}
				}));
			
			}
			
			// wait and collect all data
			for (Future<GetDeviceTypeResponse> future : res)
				System.out.println(future.get());

		}
		
		client.shutdown();
	}

	// 没有签名https同步调用接口示例
	@Test
	public void testApiWithSsl() throws Exception {

		DeviceArchivesClient client = DeviceArchivesClient.newClient().scheme(Scheme.HTTPS).build();

		{
			DeleteArchivesInfoRequest request = new DeleteArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.DeleteArchivesInfo(request));
		}
		
		{
			GetArchivesAttributeRequest request = new GetArchivesAttributeRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetArchivesAttribute(request));
		}
		
		{
			UpdateArchivesInfoRequest request = new UpdateArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.UpdateArchivesInfo(request));
		}
		
		{
			AddArchivesInfoRequest request = new AddArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.AddArchivesInfo(request));
		}
		
		{
			GetArchivesInfoRequest request = new GetArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetArchivesInfo(request));
		}
		
		{
			GetDeviceTypeRequest request = new GetDeviceTypeRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetDeviceType(request));
		}
		
		client.shutdown();
	}

	// 签名同步调用接口示例
	@Test
	public void testApiWithSignature() throws Exception {

		DeviceArchivesClient client = DeviceArchivesClient.newClient().appKey("Your app key here").appSecret("Your app secret here").build();

		{
			DeleteArchivesInfoRequest request = new DeleteArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.DeleteArchivesInfo(request));
		}
		
		{
			GetArchivesAttributeRequest request = new GetArchivesAttributeRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetArchivesAttribute(request));
		}
		
		{
			UpdateArchivesInfoRequest request = new UpdateArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.UpdateArchivesInfo(request));
		}
		
		{
			AddArchivesInfoRequest request = new AddArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.AddArchivesInfo(request));
		}
		
		{
			GetArchivesInfoRequest request = new GetArchivesInfoRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetArchivesInfo(request));
		}
		
		{
			GetDeviceTypeRequest request = new GetDeviceTypeRequest();
			// request.setParam..  	// set your request params here
			System.out.println(client.GetDeviceType(request));
		}
		
		client.shutdown();
	}

}
